OK_FORMAT = True

test = {   'name': 'q4_4_1',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> bool(np.isclose(proportion_in_20th_century, 0.704))\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
