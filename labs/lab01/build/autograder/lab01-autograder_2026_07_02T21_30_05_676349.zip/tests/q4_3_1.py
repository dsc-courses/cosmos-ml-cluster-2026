OK_FORMAT = True

test = {   'name': 'q4_3_1',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> bool(np.isclose(average_20th_century_rating, 8.280113636363636))\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
