OK_FORMAT = True

test = {   'name': 'q4_2',
    'points': None,
    'suites': [{'cases': [{'code': '>>> really_highly_rated.shape == (20, 4)\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
